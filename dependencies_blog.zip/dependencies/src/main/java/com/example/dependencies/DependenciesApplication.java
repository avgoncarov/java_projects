package com.example.dependencies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DependenciesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DependenciesApplication.class, args);
	}

}
