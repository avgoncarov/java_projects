package com.example.dependencies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DependenciesApplicationTests {

	@Test
	void contextLoads() {
	}

}
