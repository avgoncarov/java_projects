package com.example.springapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
